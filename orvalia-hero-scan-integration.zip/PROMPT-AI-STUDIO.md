Cole isto no AI Studio (de preferência anexando também o `BusinessScan.tsx` que já vai pronto — assim ele só integra, não recria do zero):

---

Preciso integrar um novo componente ao meu site orvalia.com.br (React 18 + Vite + Tailwind + framer-motion + lucide-react, com SSG via vite-react-ssg).

**Contexto de design que você DEVE seguir à risca — não crie um estilo novo:**
- Cores em `tailwind.config.js`: `brand.bg #0D1117`, `brand.surface #141820`, `brand.card #12161F`, `brand.text #EAECEF`, `brand.secondary #A0A8B8`, `brand.red #E5383B` (vermelho de diagnóstico/CTA), `brand.accent.teal #79DEC8`.
- Fonte única: Hanken Grotesk (`font-sans`), pesos extrabold/black nos títulos, tracking negativo (`tracking-[-0.03em]`) nos headlines.
- Labels em caixa alta com `font-mono text-xs uppercase tracking-[0.3em] text-brand-red`, sempre com um quadradinho `w-2 h-2 bg-brand-red` antes.
- Botões primários: `bg-brand-red hover:bg-red-600 text-white font-black uppercase tracking-[0.2em]`, sem `rounded` (cantos retos).
- Cards/painéis: `bg-white/[0.02] border border-white/10` (classe utilitária `.glass` já existe em `index.css`).
- Animações de entrada: `framer-motion`, fade+slide-up (`initial={{opacity:0,y:16}} animate={{opacity:1,y:0}}`), duração 0.5–0.8s.
- Reaproveite exatamente os padrões visuais de `src/components/Hero.tsx` e `src/components/GapPercepcao.tsx` (já estão no repo) — não invente variações de paleta ou tipografia.

**Tarefa:**
1. Adicione o componente `src/components/BusinessScan.tsx` (anexado) ao projeto sem alterar sua lógica ou estilos.
2. Em `src/pages/Home.tsx`, importe `BusinessScan` e renderize `<BusinessScan />` imediatamente depois de `<Hero />` e antes de `<GapPercepcao />` — ele é o carro-chefe logo abaixo da dobra, não uma seção qualquer lá embaixo.
3. Garanta que exista a env var `VITE_SCAN_API_URL` (arquivo `.env`) apontando para o backend do scan (Node/Express separado, já tenho o código, só falta hospedar).
4. Não mexa em `Hero.tsx`, `GapPercepcao.tsx` nem em outros componentes — o objetivo é inserir, não reescrever o que já existe.

Confirme o diff antes de aplicar.

---
