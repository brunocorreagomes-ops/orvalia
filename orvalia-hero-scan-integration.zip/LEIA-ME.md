# Orvalia Business Scan → carro-chefe da hero page

## O que está aqui
- `patch-orvalia-site/src/components/BusinessScan.tsx` → componente novo, pronto pra colar no repo do site.
- `patch-orvalia-site/src/pages/Home.tsx` → sua Home.tsx já com o BusinessScan importado e inserido logo após o `<Hero />`.
- `patch-scan-backend/server.js` → seu server.js atual + CORS liberado para orvalia.com.br (sem isso o site não consegue chamar a API do scan).

## Passo a passo

1. **Copie `BusinessScan.tsx`** para `src/components/` no repo do site (o mesmo onde estão `Hero.tsx`, `GapPercepcao.tsx` etc.).
2. **Substitua seu `src/pages/Home.tsx`** pelo daqui (ou só adicione as duas linhas de import + `<BusinessScan />` manualmente).
3. **Suba o backend do scan em algum lugar público** — ele não pode continuar só no seu localhost, porque o site é estático (Vite/SSG) e não tem servidor próprio para rodar a lógica do Gemini. Mais simples: Render.com (free tier) ou Railway.
   - Suba a pasta `orvalia-business-scan-mvp2` como Web Service Node.
   - Configure lá as env vars `GEMINI_API_KEY` e `GEMINI_MODEL`.
   - Troque o `server.js` de lá pelo daqui (`patch-scan-backend/server.js`), que já libera CORS para `orvalia.com.br`.
4. **No repo do site**, crie/edite o `.env`:
   ```
   VITE_SCAN_API_URL=https://SEU-BACKEND-NO-RENDER.onrender.com
   ```
5. Rode `npm run dev` e confira a seção logo abaixo do Hero.

## Se preferir fazer isso direto no Google AI Studio
Veja `PROMPT-AI-STUDIO.md` — é o texto pronto pra colar lá.
