import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { promises as fs } from "node:fs";
import { runBusinessScan } from "./src/gemini.js";
import { validateAnalysisShape } from "./src/validate.js";
import { calculateScores, buildPublicResult } from "./src/score.js";

const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, "public");

const ALLOWED_ORIGINS = new Set([
  "https://orvalia.com.br",
  "https://www.orvalia.com.br",
  "http://localhost:3000",
  "http://localhost:5173"
]);

function applyCors(req, res) {
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  }
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".ico": "image/x-icon"
};

function sendJson(res, status, payload) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(JSON.stringify(payload));
}

async function readJsonBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 200_000) throw new Error("Payload muito grande.");
    chunks.push(chunk);
  }
  const text = Buffer.concat(chunks).toString("utf8");
  return JSON.parse(text || "{}");
}

function cleanText(value, maxLength = 180) {
  return String(value ?? "").trim().slice(0, maxLength);
}

function normalizeUrl(value) {
  let url = cleanText(value, 500);
  if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
  const parsed = new URL(url);
  if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("URL inválida.");
  return parsed.toString();
}

function validateRequest(body) {
  const input = {
    companyName: cleanText(body.companyName),
    websiteUrl: normalizeUrl(body.websiteUrl),
    segment: cleanText(body.segment),
    city: cleanText(body.city),
    contactName: cleanText(body.contactName),
    email: cleanText(body.email, 240),
    whatsapp: cleanText(body.whatsapp, 40)
  };

  for (const field of ["companyName", "websiteUrl", "segment", "city", "contactName", "email", "whatsapp"]) {
    if (!input[field]) throw new Error(`Campo obrigatório ausente: ${field}`);
  }
  if (!/^\S+@\S+\.\S+$/.test(input.email)) throw new Error("E-mail inválido.");
  return input;
}

async function saveLead(input, publicResult) {
  const dataDir = path.join(__dirname, "data");
  await fs.mkdir(dataDir, { recursive: true });
  const record = {
    created_at: new Date().toISOString(),
    contact_name: input.contactName,
    email: input.email,
    whatsapp: input.whatsapp,
    company_name: input.companyName,
    website_url: input.websiteUrl,
    segment: input.segment,
    city: input.city,
    business_score: publicResult.business_score,
    classification: publicResult.classification
  };
  await fs.appendFile(path.join(dataDir, "leads.jsonl"), `${JSON.stringify(record)}\n`, "utf8");
}

async function handleScan(req, res) {
  try {
    const body = await readJsonBody(req);
    const input = validateRequest(body);
    const analysis = await runBusinessScan(input);
    validateAnalysisShape(analysis);
    const scores = calculateScores(analysis);
    const publicResult = buildPublicResult(analysis, scores);

    saveLead(input, publicResult).catch((error) => console.error("Falha ao salvar lead:", error));
    sendJson(res, 200, publicResult);
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Erro inesperado.";
    const status = /GEMINI_API_KEY/.test(message) ? 500 : 400;
    sendJson(res, status, { error: message });
  }
}

async function serveStatic(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === "/") pathname = "/index.html";

  const requested = path.normalize(path.join(publicDir, pathname));
  if (!requested.startsWith(publicDir)) {
    res.writeHead(403); res.end("Forbidden"); return;
  }

  try {
    const data = await fs.readFile(requested);
    res.writeHead(200, {
      "Content-Type": MIME[path.extname(requested).toLowerCase()] || "application/octet-stream",
      "Cache-Control": pathname === "/index.html" ? "no-cache" : "public, max-age=3600"
    });
    res.end(data);
  } catch {
    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Not found");
  }
}

const server = http.createServer(async (req, res) => {
  applyCors(req, res);
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }
  if (req.method === "GET" && req.url === "/api/health") {
    return sendJson(res, 200, { ok: true, model: process.env.GEMINI_MODEL || "gemini-3.6-flash" });
  }
  if (req.method === "POST" && req.url === "/api/business-scan") {
    return handleScan(req, res);
  }
  if (req.method === "GET") return serveStatic(req, res);
  res.writeHead(405, { "Allow": "GET, POST" });
  res.end("Method Not Allowed");
});

server.listen(port, () => {
  console.log(`Orvalia Business Scan MVP: http://localhost:${port}`);
});
