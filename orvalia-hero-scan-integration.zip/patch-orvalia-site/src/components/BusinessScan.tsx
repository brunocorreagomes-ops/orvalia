import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowUpRight, Loader2, Lock, RotateCcw } from "lucide-react";

// Aponte para onde o backend Node do Business Scan estiver hospedado.
// Local: http://localhost:3000 · Produção: defina VITE_SCAN_API_URL no .env do site.
const API_URL = import.meta.env.VITE_SCAN_API_URL || "http://localhost:3000";
const WHATSAPP_NUMBER = "5511978959567";

type FormState = {
  websiteUrl: string;
  companyName: string;
  segment: string;
  city: string;
  contactName: string;
  email: string;
  whatsapp: string;
};

type Pillar = { pillar_id: string; label: string; score: number | null; coverage: number };
type Problem = { title: string; severity: string; evidence: string; impact: string; pillar_id: string };
type Opportunity = { title: string; potential: string; reason: string; pillar_id: string };
type ScanResult = {
  business_score: number;
  classification: string;
  executive_insight: string;
  pillars: Pillar[];
  top_problems: Problem[];
  top_opportunities: Opportunity[];
  total_findings: number;
  locked: { problems: number; opportunities: number };
};

const EMPTY_FORM: FormState = {
  websiteUrl: "",
  companyName: "",
  segment: "",
  city: "",
  contactName: "",
  email: "",
  whatsapp: "",
};

type Step = "form" | "loading" | "result" | "error";

export default function BusinessScan() {
  const [step, setStep] = useState<Step>("form");
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState("");

  function update<K extends keyof FormState>(field: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStep("loading");
    setError("");
    try {
      const res = await fetch(`${API_URL}/api/business-scan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Não foi possível concluir o scan agora.");
      setResult(data);
      setStep("result");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro inesperado. Tente novamente.");
      setStep("error");
    }
  }

  function reset() {
    setForm(EMPTY_FORM);
    setResult(null);
    setStep("form");
  }

  const worstPillar = result
    ? [...result.pillars].filter((p) => p.score !== null).sort((a, b) => (a.score as number) - (b.score as number))[0]
    : null;

  const hiddenFindings = result
    ? Math.max(result.total_findings - result.top_problems.length - result.top_opportunities.length, 0)
    : 0;

  const waMessage = result
    ? `Olá, Bruno. Sou ${form.contactName}, da ${form.companyName}. Fiz o Business Scan e tirei ${result.business_score}/100.` +
      (worstPillar ? ` O maior gap foi em ${worstPillar.label} (${worstPillar.score}/100).` : "") +
      ` Quero o Diagnóstico Estratégico completo com o plano de ação.`
    : "";

  return (
    <section
      id="business-scan"
      className="relative py-24 md:py-36 bg-brand-bg border-b border-white/5 overflow-hidden"
    >
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:24px_24px]" />

      <div className="container mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="max-w-4xl mb-14 md:mb-20 space-y-6">
          <div className="flex items-center gap-3">
            <span className="w-2 h-2 bg-brand-red" />
            <span className="font-mono text-xs uppercase tracking-[0.3em] text-brand-red font-semibold">
              ORVALIA BUSINESS SCAN // DIAGNÓSTICO AUTOMATIZADO
            </span>
          </div>

          <h2 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-sans font-extrabold text-white leading-[1.04] tracking-[-0.03em]">
            Não acredite na minha palavra. <br />
            <span className="text-brand-secondary">Rode o scan.</span>
          </h2>

          <p className="text-lg md:text-2xl text-brand-secondary leading-relaxed max-w-3xl">
            Em menos de 2 minutos, a IA da Orvalia cruza o site da sua empresa com evidências públicas
            e mede, nos mesmos 6 pilares que usamos com clientes, a distância entre o que você entrega
            e o que o digital consegue provar.
          </p>
        </div>

        <AnimatePresence mode="wait">
          {step === "form" && (
            <motion.form
              key="form"
              onSubmit={handleSubmit}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.5 }}
              className="glass p-6 md:p-12 grid grid-cols-1 md:grid-cols-2 gap-5"
            >
              <Field label="Site da empresa" wide>
                <input
                  required
                  placeholder="www.suaempresa.com.br"
                  value={form.websiteUrl}
                  onChange={(e) => update("websiteUrl", e.target.value)}
                />
              </Field>
              <Field label="Empresa">
                <input
                  required
                  placeholder="Nome da empresa"
                  value={form.companyName}
                  onChange={(e) => update("companyName", e.target.value)}
                />
              </Field>
              <Field label="Segmento">
                <input
                  required
                  placeholder="Ex.: Clínica odontológica"
                  value={form.segment}
                  onChange={(e) => update("segment", e.target.value)}
                />
              </Field>
              <Field label="Cidade / região">
                <input
                  required
                  placeholder="Ex.: Indaiatuba, SP"
                  value={form.city}
                  onChange={(e) => update("city", e.target.value)}
                />
              </Field>
              <Field label="Seu nome">
                <input
                  required
                  placeholder="Nome"
                  value={form.contactName}
                  onChange={(e) => update("contactName", e.target.value)}
                />
              </Field>
              <Field label="E-mail">
                <input
                  required
                  type="email"
                  placeholder="voce@empresa.com.br"
                  value={form.email}
                  onChange={(e) => update("email", e.target.value)}
                />
              </Field>
              <Field label="WhatsApp">
                <input
                  required
                  type="tel"
                  placeholder="(19) 99999-9999"
                  value={form.whatsapp}
                  onChange={(e) => update("whatsapp", e.target.value)}
                />
              </Field>

              <div className="md:col-span-2 flex flex-col sm:flex-row sm:items-center gap-4 pt-2">
                <button
                  type="submit"
                  className="flex items-center justify-center gap-3 px-8 py-5 bg-brand-red hover:bg-red-600 text-white transition-colors font-sans text-xs md:text-sm font-black uppercase tracking-[0.2em] shadow-lg shadow-brand-red/20"
                >
                  <span>Executar Business Scan</span>
                  <ArrowUpRight size={18} />
                </button>
                <span className="font-mono text-[10px] uppercase tracking-widest text-brand-secondary">
                  Sem login · leva 2 minutos · resultado imediato
                </span>
              </div>
            </motion.form>
          )}

          {step === "loading" && (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="glass flex items-center gap-6 p-10 md:p-14"
            >
              <Loader2 className="text-brand-red animate-spin shrink-0" size={30} />
              <div>
                <div className="font-mono text-xs uppercase tracking-[0.3em] text-brand-red font-semibold mb-2">
                  Análise em andamento
                </div>
                <p className="text-brand-secondary">
                  Verificando evidências públicas e estruturando seu diagnóstico inicial.
                </p>
              </div>
            </motion.div>
          )}

          {step === "error" && (
            <motion.div
              key="error"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="p-8 md:p-10 border border-brand-red/40 bg-brand-red/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-6"
            >
              <p className="text-brand-text">{error}</p>
              <button
                onClick={() => setStep("form")}
                className="px-6 py-3 border border-white/20 text-white hover:border-white hover:bg-white/5 transition-all text-xs font-black uppercase tracking-[0.2em] flex items-center gap-2 shrink-0"
              >
                <RotateCcw size={14} /> Tentar novamente
              </button>
            </motion.div>
          )}

          {step === "result" && result && (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="space-y-6"
            >
              {/* Score + pillars */}
              <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                <div className="md:col-span-2 glass p-8 flex flex-col justify-between">
                  <div>
                    <div className="flex items-end gap-2">
                      <span className="font-sans font-black text-white text-7xl md:text-8xl leading-none tracking-[-0.05em]">
                        {result.business_score}
                      </span>
                      <span className="text-brand-secondary text-lg mb-2">/100</span>
                    </div>
                    <span className="inline-block mt-5 border border-brand-red/40 bg-brand-red/10 text-white px-3 py-1.5 text-[11px] font-mono uppercase tracking-widest">
                      {result.classification}
                    </span>
                  </div>
                  <p className="text-brand-secondary leading-relaxed mt-8">{result.executive_insight}</p>
                </div>

                <div className="md:col-span-3 glass p-8">
                  <div className="font-mono text-xs uppercase tracking-widest text-white mb-6">
                    6 pilares analisados
                  </div>
                  <div className="space-y-5">
                    {result.pillars.map((p) => (
                      <div key={p.pillar_id}>
                        <div className="flex justify-between text-sm mb-1.5">
                          <span className="text-brand-secondary">{p.label}</span>
                          <span className="text-white font-bold">{p.score ?? "—"}</span>
                        </div>
                        <div className="h-1.5 w-full bg-neutral-900 border border-white/10 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${p.score ?? 0}%` }}
                            transition={{ duration: 1, ease: "easeOut" }}
                            className="h-full bg-brand-red"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Maior gap */}
              {worstPillar && (
                <div className="p-8 md:p-10 border border-white/10 bg-white/[0.01]">
                  <div className="flex flex-col md:flex-row justify-between md:items-center gap-3 mb-4">
                    <span className="font-mono text-xs uppercase tracking-widest text-brand-red font-bold">
                      [!] MAIOR GAP IDENTIFICADO
                    </span>
                    <span className="font-mono text-[10px] uppercase tracking-widest text-brand-secondary">
                      Potencial de evolução
                    </span>
                  </div>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <h3 className="text-2xl md:text-3xl font-sans font-bold text-white tracking-tight">
                      {worstPillar.label}
                    </h3>
                    <span className="font-sans font-black text-brand-red text-4xl md:text-5xl leading-none">
                      {worstPillar.score}
                      <small className="text-brand-secondary text-base font-normal ml-1">/100</small>
                    </span>
                  </div>
                </div>
              )}

              {/* Riscos e oportunidades */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass p-8">
                  <span className="font-mono text-xs uppercase tracking-widest text-brand-red font-bold">
                    Riscos prioritários
                  </span>
                  <div className="mt-5 space-y-5">
                    {result.top_problems.map((item, i) => (
                      <div key={i} className="pt-5 border-t border-white/10 first:pt-0 first:border-0">
                        <div className="flex justify-between gap-3 text-white font-bold text-sm">
                          <span>{item.title}</span>
                          <span className="shrink-0 border border-white/10 text-brand-secondary text-[10px] uppercase tracking-widest px-2 py-1 h-fit">
                            {item.severity}
                          </span>
                        </div>
                        <p className="text-brand-secondary text-sm leading-relaxed mt-2">{item.evidence}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="glass p-8">
                  <span className="font-mono text-xs uppercase tracking-widest text-[#79DEC8] font-bold">
                    Oportunidades
                  </span>
                  <div className="mt-5 space-y-5">
                    {result.top_opportunities.map((item, i) => (
                      <div key={i} className="pt-5 border-t border-white/10 first:pt-0 first:border-0">
                        <div className="flex justify-between gap-3 text-white font-bold text-sm">
                          <span>{item.title}</span>
                          <span className="shrink-0 border border-white/10 text-brand-secondary text-[10px] uppercase tracking-widest px-2 py-1 h-fit">
                            {item.potential}
                          </span>
                        </div>
                        <p className="text-brand-secondary text-sm leading-relaxed mt-2">{item.reason}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Camada bloqueada */}
              {hiddenFindings > 0 && (
                <div className="p-8 md:p-10 border border-white/10 bg-white/[0.01]">
                  <span className="font-mono text-xs uppercase tracking-widest text-white">
                    O SCAN É SÓ A PRIMEIRA CAMADA
                  </span>
                  <p className="text-brand-secondary mt-3 max-w-2xl">
                    Encontramos mais {hiddenFindings} pontos de atenção que não aparecem aqui. O
                    Diagnóstico Estratégico completo mostra todos, priorizados por impacto.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6">
                    {Array.from({ length: Math.min(hiddenFindings, 3) }).map((_, i) => (
                      <div key={i} className="p-4 border border-white/10 bg-black/30 relative overflow-hidden">
                        <Lock size={12} className="text-brand-secondary mb-3" />
                        <div className="h-2 w-4/5 bg-white/10 blur-[2px] mb-2" />
                        <div className="h-2 w-1/2 bg-white/10 blur-[2px]" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* CTA final — mesma linguagem do banner de fechamento usado no resto do site */}
              <div className="mt-4 p-8 md:p-12 border border-brand-red/40 bg-brand-red/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-2">
                  <span className="font-mono text-xs uppercase tracking-widest text-brand-red font-bold">
                    PRÓXIMO PASSO
                  </span>
                  <h4 className="text-2xl md:text-3xl font-sans font-bold text-white tracking-tight max-w-xl">
                    Transforme os achados em um plano de ação 30/60/90 com o Bruno.
                  </h4>
                </div>
                <a
                  href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(waMessage)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-4 bg-brand-red hover:bg-red-600 text-white font-black text-xs uppercase tracking-widest flex items-center gap-3 shrink-0 transition-colors"
                >
                  <span>Chamar o Bruno no WhatsApp</span>
                  <ArrowUpRight size={16} />
                </a>
              </div>

              <button
                onClick={reset}
                className="flex items-center gap-2 text-brand-secondary hover:text-white text-xs font-mono uppercase tracking-widest transition-colors pt-2"
              >
                <RotateCcw size={12} /> Rodar novo scan
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}

function Field({
  label,
  wide,
  children,
}: {
  label: string;
  wide?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className={`flex flex-col gap-2 ${wide ? "md:col-span-2" : ""}`}>
      <span className="font-mono text-[10px] uppercase tracking-widest text-brand-secondary">{label}</span>
      <span className="[&>input]:w-full [&>input]:bg-white/[0.02] [&>input]:border [&>input]:border-white/10 [&>input]:text-white [&>input]:px-4 [&>input]:py-3.5 [&>input]:outline-none [&>input]:transition-colors [&>input:focus]:border-brand-red/60 [&>input::placeholder]:text-white/25">
        {children}
      </span>
    </label>
  );
}
